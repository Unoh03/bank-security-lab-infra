"""Minimal disposable Shuffle Cloud upload canary."""

from shuffle_sdk import AppBase


class AwsTopologyValidatorShapeCanary(AppBase):
    __version__ = "0.0.2"
    app_name = "SOC Validator Shape Canary"

    def validate_sanitized_alert(self, input_data):
        return {"valid": False, "rejection": "CANARY"}

    def classify_dedupe_claim(self, claim_result, expected_key):
        return {"valid": False, "existed": True, "reason_code": "CANARY"}


if __name__ == "__main__":
    AwsTopologyValidatorShapeCanary.run()
