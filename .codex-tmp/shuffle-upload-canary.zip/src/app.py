"""Minimal disposable Shuffle Cloud upload canary."""

from shuffle_sdk import AppBase


class AwsTopologyUploadCanary(AppBase):
    __version__ = "0.0.1"
    app_name = "AWS Topology Upload Canary"

    def repeat_canary(self, text):
        return text


if __name__ == "__main__":
    AwsTopologyUploadCanary.run()
